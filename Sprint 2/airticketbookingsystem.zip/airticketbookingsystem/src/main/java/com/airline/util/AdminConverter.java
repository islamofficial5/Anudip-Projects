package com.airline.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.airline.entity.Admin;
import com.airline.model.AdminDTO;

@Component
public class AdminConverter {
	
	
	//convert from AdminDTO to Entity(Admin)
		
		public Admin covertToAdminEntity(AdminDTO adminDTO)
		{
			Admin admin=new Admin();
			
			if(adminDTO!=null)
			{
				BeanUtils.copyProperties(adminDTO, admin);
			}
			return admin;
		}
		
		
		//covert from passenger Entity to AdminDTO
		
		
		public AdminDTO convertToAdminDTO(Admin admin)
		
		{
			AdminDTO adminDTO=new AdminDTO();
			if(admin!=null)
			{
				BeanUtils.copyProperties(admin, adminDTO);
			}
			return adminDTO;
		}

}
