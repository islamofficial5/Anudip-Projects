package com.airline.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.entity.Passenger;
import com.airline.exception.ResourceNotFoundException;
import com.airline.model.PassengerDTO;
import com.airline.repository.PassengerRepository;
import com.airline.service.PassengerService;
import com.airline.util.PassengerConverter;

@Service
public class PassengerServiceImpl implements PassengerService{

	//logger statically created
		private static final Logger L=LoggerFactory.getLogger(PassengerService.class);
	@Autowired
	private PassengerRepository passengerRepository;
	
	@Autowired
	private PassengerConverter converter;
	
	//this method is for createPassenger Service layer
	@Override
	public String createPassenger(Passenger passenger) {
		String message=null;
		passenger.setUserName(passenger.getUserName());
		passenger.setPassword(passenger.getPassword());
		passenger.setRole(passenger.getRole());
		
		passengerRepository.save(passenger);
		L.info("Passenger"+passenger.toString()+" added at"+ new java.util.Date());
		
		if(passenger!=null)
		{
			message="Passenger saved Successfully!!";
		}
		return message;
	}

	//Service layer for updatePassenger 
	@Override
	public PassengerDTO updatePassenger(int id, Passenger passenger) {
		//we need to check whether passenger with given id is exist in DB or not
		
		Passenger existingPass=passengerRepository.findById(id).orElseThrow(()->
		new ResourceNotFoundException("Passenger", "id", id));
		
		//we will get data from client and set in existing passenger
		existingPass.setName(passenger.getName());
		existingPass.setPhno(passenger.getPhno());
		existingPass.setEmail(passenger.getEmail());
		existingPass.setUserName(passenger.getUserName());
		existingPass.setPassword(passenger.getPassword());
		existingPass.setRole(passenger.getRole());
		
		passengerRepository.save(existingPass);
		L.info("Passenger"+passenger.toString()+" updated at"+ new java.util.Date());
		
		return converter.convertToPassengerDTO(existingPass);
	}
	
	//Service layer for getPassengerById 
	@Override
	public PassengerDTO getPassengerById(int id) {
		
//	Optional<Passenger> opPassenger =passengerRepository.findById(id);
//	
//	Passenger pass=null;
//		if(opPassenger.isPresent())
//		{
//			pass=opPassenger.get();
//		}
//		else
//		{
//			throw new ResourceNotFoundException("Passenger", "Id", id);
//		}
		L.info("Getting Passenger By "+id+" at "+ new java.util.Date());
		Passenger pass=passengerRepository.findById(id).orElseThrow(()->
        new ResourceNotFoundException("Passenger", "id", id));
		return converter.convertToPassengerDTO(pass);
	}
	
	//Service layer for getAllPassenger 

	@Override
	public List<PassengerDTO> getAllPassenger() {
		List<Passenger> passengers=passengerRepository.findAll();
		
		List<PassengerDTO> passengersDTO=new ArrayList<>();
		for(Passenger pass: passengers)
		{
			passengersDTO.add(converter.convertToPassengerDTO(pass));
		}
		L.info("Getting All Passenger Details "+passengers.toString()+" at "+ new java.util.Date());
		return passengersDTO;
	}

	//Service layer for deletePassenger 
	@Override
	public String deletePassenger(int id) {
		String msg=null;
		Optional<Passenger> opPass =passengerRepository.findById(id);
		if(opPass.isPresent())
		{
			passengerRepository.deleteById(id);
			L.info("Deleting  Passenger by "+id +" at "+ new java.util.Date());
			msg="Record deleted successfully!!";
		}
		else
		{
			throw new ResourceNotFoundException("Passenger", "ID", id);
		}
		return msg;
	}
	
	//Service layer for getPassengerByName 

	@Override
	public List<PassengerDTO> getPassengerByName(String name) {
		List<Passenger> passengers=passengerRepository.getPassengerByName(name);
		
		List<PassengerDTO> pDTO=new ArrayList<>();
		for(Passenger p: passengers)
		{
			pDTO.add(converter.convertToPassengerDTO(p));
		}
		L.info("Getting All Passenger Details By "+name+ passengers.toString() +" at "+ new java.util.Date());
		return pDTO;
	}

	//Service layer for getPassengerByEmail 
	@Override
	public PassengerDTO getPassengerByEmail(String email) {
		Passenger passenger=passengerRepository.getPassengerByEmail(email);
		L.info("Getting All Passenger Details By "+email+ passenger.toString() +" at "+ new java.util.Date());
		return converter.convertToPassengerDTO(passenger);
	}

	
	
}
