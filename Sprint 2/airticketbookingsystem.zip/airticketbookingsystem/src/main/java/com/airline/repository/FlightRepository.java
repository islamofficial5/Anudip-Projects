package com.airline.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.airline.entity.Admin;
import com.airline.entity.Flight;

public interface FlightRepository extends JpaRepository<Flight, Integer>
{
	
	@Query("select f from Flight f where f.source=:s and f.destination=:d")
	List<Flight> findBySourceAndDestination(@Param("s") String source , @Param("d") String destination);
}
