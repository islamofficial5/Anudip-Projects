package com.airline.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airline.entity.TicketBooking;
import com.airline.model.TicketBookingDTO;
import com.airline.service.TicketBookingService;
import com.airline.util.TicketBookingConverter;


@RestController
@RequestMapping("/api")
public class TicketController {

	@Autowired
	TicketBookingService ticketBookingService;
	
	@Autowired
	TicketBookingConverter ticketConverter;
	
	//build ticket booking using REST API
	@PostMapping("/bookFlight/{fid}/{pid}")
	public String bookFlight(@PathVariable("fid") int fid,
			@PathVariable("pid") int pid,
			@RequestBody TicketBookingDTO ticketBookingDTO)
	{
		final TicketBooking booking = ticketConverter.convertToTicketEntity(ticketBookingDTO);
		return ticketBookingService.bookFlight(fid, pid, booking);
	}
	
	//cancel booking using id
	@DeleteMapping("/cancelBooking/{id}")
	public String cancelBooking(@PathVariable("id") int id)
	{
		return ticketBookingService.cancelBooking(id);
	}
	
	//build GET ticket by id REST API
	@GetMapping("/getBoardingPass/{id}")
	public TicketBookingDTO getBoardingPass(@PathVariable int id)
	{
		
		return ticketBookingService.getBoardingPass(id);
		
		}

	
	//build GET ALL Ticket details REST API
	@GetMapping("/getAllTicketBooking")
	public List<TicketBookingDTO> getAllTicketBooking()
	{
		return ticketBookingService.getAllBookingTicket();
	}
}
