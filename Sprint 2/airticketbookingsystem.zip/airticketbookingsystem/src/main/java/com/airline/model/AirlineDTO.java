package com.airline.model;

import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.airline.entity.Flight;

import lombok.Data;




@Data
public class AirlineDTO {

	private int id;
   @NotNull()
   @Size(min = 2, message = "airline name should have minimum 2 characters ")
	private String airlineName;
   
    @NotNull()
	private float fare;

	List<Flight> flights;

	
	
	
}
