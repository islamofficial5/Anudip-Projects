package com.airline.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.entity.Admin;
import com.airline.entity.Airline;
import com.airline.entity.Flight;
import com.airline.entity.Passenger;
import com.airline.exception.ResourceNotFoundException;
import com.airline.model.AdminDTO;
import com.airline.model.AirlineDTO;
import com.airline.model.PassengerDTO;
import com.airline.repository.AirlineRepository;
import com.airline.repository.PassengerRepository;
import com.airline.service.AdminService;
import com.airline.service.AirlineService;
import com.airline.util.AirlineConverter;

@Service
public class AirlineServiceImpl implements AirlineService{
	
	//logger statically created
	private static final Logger L=LoggerFactory.getLogger(AirlineService.class);

	@Autowired
	private AirlineRepository airlineRepository;
	
	@Autowired
	AirlineConverter airlineconverter;
	
	//Service layer for saveAirline
	
	@Override
	public AirlineDTO saveAirline(Airline airline) {
		Airline airlines =airlineRepository.save(airline);
		L.info("Airline"+airline.toString()+" added at "+ new java.util.Date());
		return airlineconverter.convertToAirlineDTO(airlines);
	}

	//Service layer for updateAirline
	@Override
	public AirlineDTO updateAirline(int id, Airline airline) {
		//we need to check whether airline with given id is exist in DB or not
		
				Airline existingAirline=airlineRepository.findById(id).orElseThrow(()->
				new ResourceNotFoundException("Airline", "id", id));
				
				//we will get data from client and set in existing passenger
				existingAirline.setAirlineName(airline.getAirlineName());
				existingAirline.setFare(airline.getFare());
				
				airlineRepository.save(existingAirline);
				L.info("Airline"+airline.toString()+" updated at "+ new java.util.Date());
				
				return airlineconverter.convertToAirlineDTO(existingAirline);
	}

	//Service layer for getAirlineById
	@Override
	public AirlineDTO getAirlineById(int id) {
		Airline airline =airlineRepository.findById(id).orElseThrow(()->
        new ResourceNotFoundException("Airline", "id", id));
		L.info("getting Airline details by "+id+" "+airline.toString()+"  at "+ new java.util.Date());
		return airlineconverter.convertToAirlineDTO(airline);
	}

	//Service layer for getAllAirline
	@Override
	public List<AirlineDTO> getAllAirline() {
		List<Airline> airlines =airlineRepository.findAll();
		
		List<AirlineDTO> airlineDTOs =new ArrayList<>();
		for(Airline air: airlines)
		{
			airlineDTOs.add(airlineconverter.convertToAirlineDTO(air));
		}
		L.info("Getting All Airline details "+" at "+ new java.util.Date());
		return airlineDTOs;
	
	}
		
	//Service layer for deleteAirline

	@Override
	public String deleteAirline(int id) {
		String msg=null;
		Optional<Airline> opAirline =airlineRepository.findById(id);
		if(opAirline.isPresent())
		{
			airlineRepository.deleteById(id);
			msg="Record deleted successfully!!";
			L.info("Deleting  Airline by "+id +" at "+ new java.util.Date());
		}
		else
		{
			throw new ResourceNotFoundException("Airline", "ID", id);
		}
		return msg;
	
	}

		
	//Service layer for getAirlineByName
	@Override
	public List<AirlineDTO> getAirlineByName(String airlineName)
	{
		List<Airline> airline=airlineRepository.getAirlineByName(airlineName);
		
		List<AirlineDTO> aDTO=new ArrayList<>();
		for(Airline a: airline)
		{
			aDTO.add(airlineconverter.convertToAirlineDTO(a));	
		}
		L.info("Getting All Airline details by "+airlineName+" at "+ new java.util.Date());
		return aDTO;
	}



	
	}
