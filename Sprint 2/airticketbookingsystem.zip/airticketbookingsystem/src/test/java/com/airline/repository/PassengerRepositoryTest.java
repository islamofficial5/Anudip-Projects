package com.airline.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import com.airline.entity.Passenger;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class PassengerRepositoryTest
{
	@Autowired
	private PassengerRepository passengerRepository;
	
	//this method is for testing savePassenger Repository layer
	@Test
//	@Rollback(value = false)
	@Order(1)
	void savePassengerTest()
	{
		Passenger passenger=Passenger.builder().name("islam").email("islamm@gmail.com").phno("8235425566").
				userName("islam").password("islam123").role("user").build();
		
		Passenger p=passengerRepository.save(passenger);
		
		assertThat(p.getName()).isEqualTo("islam");
	}
	
	//this method is for testing getAllPassenger Repository layer
	@Test
	@DisplayName("getAllPassenger method")
	@Rollback(value = false)
	@Order(3)
	void getAllPassengerTest()
	{
		List<Passenger> list=passengerRepository.findAll();
		assertThat(list.size()).isGreaterThan(0);
	}
	
	//this method is for testing updatePassenger Repository layer
	@Test
	@DisplayName("updatePassenger method")
//	@Rollback(value = false)
	@Order(2)
	void updatePassengerTest()
	{
		Passenger exPass=passengerRepository.findById(2).get();
		exPass.setName("islam");
		
		Passenger p=passengerRepository.save(exPass);
		assertThat(p.getName()).isEqualTo("islam");
	}
	
	
	//this method is for testing deletePassenger Repository layer
	@Test
	@DisplayName("deletePassenger method")
	@Order(4)
	void deletePassenger()
	{
		passengerRepository.deleteById(4);
		assertThrows(NoSuchElementException.class,()-> passengerRepository.findById(4).get());
		
	}
	
	//this method is for testing negative case updatePassenger Repository layer
	@Test
	@DisplayName("negative test case")
//	@Rollback(value = false)
	@Order(5)
	void updatePassengerNegative()
	{
		Passenger exPass=passengerRepository.findById(4).get();
		exPass.setName("islam");
		Passenger p=passengerRepository.save(exPass);
		
		assertThat(p.getName()).isEqualTo("suraj");
	}

}
