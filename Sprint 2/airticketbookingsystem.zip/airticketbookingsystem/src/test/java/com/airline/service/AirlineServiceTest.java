package com.airline.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.airline.entity.Airline;
import com.airline.entity.Flight;
import com.airline.entity.Passenger;
import com.airline.model.AirlineDTO;
import com.airline.model.FlightDTO;
import com.airline.model.PassengerDTO;
import com.airline.repository.AirlineRepository;
import com.airline.service.AirlineService;
import com.airline.util.AirlineConverter;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest
public class AirlineServiceTest
{
	
	//logger statically created
		private static final Logger L=LoggerFactory.getLogger(AirlineService.class);
		
	@Autowired
	AirlineService airlineService;
	
	@Autowired
	AirlineConverter airlineConverter;
	
	@MockBean
	AirlineRepository airlineRepository;
	
	//this method is for testing saveAirline service layer
	@Test
	@DisplayName("saveAirline method")
	@Order(1)
	 void testSaveAirline()
	{
		Airline airline=Airline.builder().airlineName("Spicejet").fare(5050.55f).build();
		
		Optional<Airline> opAirline=Optional.of(airline);
		Mockito.when(airlineRepository.findById(airline.getId())).thenReturn(opAirline);
		
		AirlineDTO adto=airlineService.saveAirline(airline);
		L.info("Airline"+airline.toString()+" added at "+ new java.util.Date());
		assertThat(airlineService.saveAirline(airline)).isEqualTo(adto);
	}
	
	//this method is for testing updateAirline service layer
	@Test
	@DisplayName("updateAirline method")
	@Order(2)
	void testUpdateAirline()
	{
		Airline airline=Airline.builder().airlineName("Spicejet").fare(5050.55f).build();
		
		Optional<Airline> opAirline=Optional.of(airline);
		Mockito.when(airlineRepository.findById(airline.getId())).thenReturn(opAirline);
		
		Airline a=opAirline.get();
		airline.setAirlineName("Indigo");
		
		
		Mockito.when(airlineRepository.save(airline)).thenReturn(a);
		AirlineDTO adto=airlineService.updateAirline(airline.getId(),airline);
		L.info("Airline"+airline.toString()+" updated at "+ new java.util.Date());
		assertEquals(adto.getAirlineName(), a.getAirlineName());
		
		
	}
	//this method is for testing negative case getAirlineById service layer
	@Test
	@DisplayName("Negative test case")
	@Order(5)
	void testGetAllAirline()
	{
		Airline airline=Airline.builder().airlineName("Spicejet").fare(5050.55f).build();
		
		Airline airline2=Airline.builder().airlineName("Air India").fare(6500.55f).build();
		List<Airline> list=new ArrayList<>();
			list.add(airline);
			list.add(airline2);
			
			Mockito.when(airlineRepository.findAll()).thenReturn(list);
			
			List<AirlineDTO> dto=airlineService.getAllAirline();
			L.info("getting All Airline details  "+"  at "+ new java.util.Date());
			
			List<Airline> air=new ArrayList<Airline>();
			   dto.forEach(passDto ->
			   {
				   air.add(airlineConverter.covertToAirlineEntity(passDto));
			   });
			
			   assertThat(air).isEqualTo(list);
		 
	}
	
	//this method is for testing getAirlineById service layer
	
	@Test
	@DisplayName("testGetAirlineById method")
	@Order(3)
	void testGetPassengerById()
	{
		Airline airline=Airline.builder().airlineName("Spicejet").fare(5050.55f).build();
		

		Optional<Airline> opAirline=Optional.of(airline);
		Mockito.when(airlineRepository.findById(opAirline.get().getId())).thenReturn(opAirline);
		
		AirlineDTO adto=airlineConverter.convertToAirlineDTO(airline);
		L.info("getting Airline details by "+airline.getId()+" "+airline.toString()+"  at "+ new java.util.Date());
		assertThat(airlineService.getAirlineById(airline.getId())).isEqualTo(adto);
		
	}
	
	
	//this method is for testing deleteAirline service layer
	@Test
	@DisplayName(" deleteAirline method")
	@Order(4)
	void testDeleteAirline()
	{
		Airline airline=Airline.builder().airlineName("Spicejet").fare(5050.55f).build();
		
		Optional<Airline> opAirline=Optional.of(airline);
		Mockito.when(airlineRepository.findById(opAirline.get().getId())).thenReturn(opAirline);
		L.info("Deleting Airline  "+"  at "+ new java.util.Date());
		assertThat(airlineService.deleteAirline(opAirline.get().getId())).isEqualTo("Record deleted successfully!!");
		
	}
	
	
	
	
	
	
	
	
	
	
}
