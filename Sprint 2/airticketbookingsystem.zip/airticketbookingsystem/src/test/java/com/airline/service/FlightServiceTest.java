package com.airline.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.airline.entity.Admin;
import com.airline.entity.Flight;
import com.airline.entity.Passenger;
import com.airline.model.FlightDTO;
import com.airline.model.PassengerDTO;
import com.airline.repository.FlightRepository;
import com.airline.service.FlightService;
import com.airline.util.FlightConverter;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest
public class FlightServiceTest 
{
	@Autowired
	FlightService flightService;
	
	@Autowired
	FlightConverter flightConverter;
	
	@MockBean
	FlightRepository flightRepository;
	
	
	//this method is for testing saveFlight service layer
	@Test
	@DisplayName("saveFlight method")
	@Order(1)
	 void testSaveFlight()
	{
		Flight flight=Flight.builder().availableSeats(120).totalSeats(200).travellerClass("economy").
				time("10:20 ").date(LocalDate.parse("2022-10-12")).source("delhi").destination("mumbai").build();
		
		Optional<Flight> opFlight=Optional.of(flight);
		Mockito.when(flightRepository.findById(flight.getFlight_id())).thenReturn(opFlight);
		
		FlightDTO fdto=flightService.saveFlight(flight);
		assertThat(flightService.saveFlight(flight)).isEqualTo(fdto);
	}
	
	//this method is for testing updateFlight service layer
	
	@Test
	@DisplayName("updateFlight method")
	@Order(2)
	void testUpdateFlight()
	{
		Flight flight=Flight.builder().availableSeats(120).totalSeats(200).travellerClass("economy").
				time("10:20 ").date(LocalDate.parse("2022-10-12")).source("delhi").destination("mumbai").build();
		
		Optional<Flight> opFlight=Optional.of(flight);
		Mockito.when(flightRepository.findById(flight.getFlight_id())).thenReturn(opFlight);
		
		Flight f=opFlight.get();
		flight.setSource("kolkata");
		
		Mockito.when(flightRepository.save(flight)).thenReturn(f);
		FlightDTO fdto=flightService.updateFlight(flight.getFlight_id(),flight);
		assertEquals(fdto.getSource(), f.getSource());
		
		
	}
	
	//this method is for testing negative getAllFlight service layer
	@Test
	@DisplayName("Negative test case")
	@Order(5)
	void testGetAllFlight()
	{
		Flight flight=Flight.builder().availableSeats(120).totalSeats(200).travellerClass("economy").
				time("10:20 ").date(LocalDate.parse("2022-10-12")).source("delhi").destination("mumbai").build();
		
		Flight flight2=Flight.builder().availableSeats(100).totalSeats(200).travellerClass("business").
				time("10:10").date(LocalDate.parse("2022-11-11")).source("kolkata").destination("banglore").build();
		
		List<Flight> list=new ArrayList<>();
			list.add(flight);
			list.add(flight2);
			
		Mockito.when(flightRepository.findAll()).thenReturn(list);
		
		List<FlightDTO> fdto=flightService.getAllFlight();
		
		List<Flight> fly=new ArrayList<Flight>();
		   fdto.forEach(flightDto ->
		   {
			   fly.add(flightConverter.covertToFlightEntity(flightDto));
		   });
		
		   assertThat(fly).isEqualTo(list);
	}
	
	//this method is for testing  getFlightById service layer
	
	@Test
	@DisplayName("getFlightById method")
	@Order(3)
	void testGetFlightById()
	{
		Flight flight=Flight.builder().availableSeats(120).totalSeats(200).travellerClass("economy").
				time("10:20 ").date(LocalDate.parse("2022-10-12")).source("delhi").destination("mumbai").build();
		
		Optional<Flight> opFly=Optional.of(flight);
		Mockito.when(flightRepository.findById(flight.getFlight_id())).thenReturn(opFly);
		
		FlightDTO fdto=flightConverter.convertToFlightDTO(flight);
		assertThat(flightService.getFlightById(flight.getFlight_id())).isEqualTo(fdto);
		
	}
	
	//this method is for testing deleteFlight service layer
	
	@Test
	@DisplayName("deleteFlight method")
	@Order(4)
	void testDeleteFlight()
	{
		Flight flight=Flight.builder().availableSeats(120).totalSeats(200).travellerClass("economy").
				time("10:20 ").date(LocalDate.parse("2022-10-12")).source("delhi").destination("mumbai").build();
		
		Optional<Flight> opFly=Optional.of(flight);
		Mockito.when(flightRepository.findById(opFly.get().getFlight_id())).thenReturn(opFly);
		assertThat(flightService.deleteFlight(opFly.get().getFlight_id())).isEqualTo("Record deleted successfully!!");
		
	}
	
	
	
	

}
