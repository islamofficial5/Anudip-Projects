package com.airline.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;


import com.airline.entity.Admin;
import com.airline.model.AdminDTO;
import com.airline.repository.AdminRepository;
import com.airline.service.AdminService;
import com.airline.util.AdminConverter;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)

@SpringBootTest
public class AdminServiceTest 
{
	//logger statically created
	private static final Logger L=LoggerFactory.getLogger(AdminService.class);
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private AdminConverter adminConverter;
	
	@MockBean
	private AdminRepository adminRepository;
	
	
	
	//this method is for testing createAdmin service layer
	@Test
	@DisplayName("createAdmin method")
	@Order(1)
	 void testCreateAdmin()
	{
		Admin admin =Admin.builder().aname("islam").aemail("islam@gmail.com").aphno("8235420562").
				userName("admin").password("admin123").role("admin").build();
		
		Mockito.when(adminRepository.save(admin)).thenReturn(admin);
		L.info("Admin"+admin.toString()+" added at "+ new java.util.Date());
		assertThat(adminService.createAdmin(admin)).isEqualTo("Admin saved Successfully!!");
	}
	
	
	//this method is for testing updateAdmin service layer
	@Test
	@DisplayName("updateAdmin method")
	@Order(2)
	void testUpdatePassenger()
	{
		Admin admin =Admin.builder().aname("islam").aemail("islam@gmail.com").aphno("8235420562").
				userName("admin").password("admin123").role("admin").build();
	
		Optional<Admin> opAdmin=Optional.of(admin);
		Mockito.when(adminRepository.findById(admin.getId())).thenReturn(opAdmin);
		
		Admin a=opAdmin.get();
		admin.setAname("Suraj Kumar");
		
		Mockito.when(adminRepository.save(admin)).thenReturn(a);
		AdminDTO adto=adminService.updateAdmin(admin.getId(),admin);
		L.info("Admin"+admin.toString()+" updated at "+ new java.util.Date());
		assertEquals(adto.getAname(), a.getAname());
		
		
	}
	
	
	//this method is for testing getAllAdmin service layer
	@Test
	@DisplayName("getAllAdmin method")
	@Order(3)
	void testGetAllAdmin()
	{
		Admin admin1 =Admin.builder().aname("islam").aemail("islam@gmail.com").aphno("8235420562").
				userName("admin").password("admin123").role("admin").build();
		
		
		Admin admin2 =Admin.builder().aname("Suraj").aemail("suraj@gmail.com").aphno("9572645390").
				userName("admin").password("admin123").role("admin").build();
		
		
		List<Admin> list=new ArrayList<>();
			list.add(admin1);
			list.add(admin2);
			
		Mockito.when(adminRepository.findAll()).thenReturn(list);
		
		List<AdminDTO> adto=adminService.getAllAdmin();
		L.info("Getting all Admin  "+admin1.toString()+" at "+ new java.util.Date());
		
		List<Admin> admins=new ArrayList<Admin>();
		   adto.forEach(aDto ->
		   {
			   admins.add(adminConverter.covertToAdminEntity(aDto));
		   });
		
		   assertThat(admins).isEqualTo(list);
	}
	
	//this method is for testing deleteAdmin service layer
	@Test
	@DisplayName("deleteAdmin method")
	@Order(4)
	void testDeleteAdmin()
	{
		Admin admin =Admin.builder().aname("islam").aemail("islam@gmail.com").aphno("8235420562").
				userName("admin").password("admin123").role("admin").build();
		
		Optional<Admin> opAdmin=Optional.of(admin);
		Mockito.when(adminRepository.findById(opAdmin.get().getId())).thenReturn(opAdmin);
		L.info("Deleting  Admin  "+admin.toString() +" at "+ new java.util.Date());
		assertThat(adminService.deleteAdmin(opAdmin.get().getId())).isEqualTo("Record deleted successfully!!");
		
	}
	
	//this method is for testing positive case getAdminById service layer
	
	@Test
	@DisplayName("Positive test case")
	@Order(5)
	void testNGetAdminById()
	{
		Admin admin =Admin.builder().aname("islam").aemail("islam@gmail.com").aphno("8235420562").
				userName("admin").password("admin123").role("admin").build();
		
		
		Optional<Admin> opAdmin=Optional.of(admin);
		Mockito.when(adminRepository.findById(admin.getId())).thenReturn(opAdmin);
		
		AdminDTO adto=adminConverter.convertToAdminDTO(admin);
		L.info("Getting  Admin by "+admin.getId() +" at "+ new java.util.Date());
		assertThat(adminService.getAdminById(admin.getId())).isEqualTo(adto);
		
	}
	
	//this method is for testing negative case for getAdminById service layer
	@Test
	@DisplayName("Negative test case")
	@Order(6)
	void testNegativeGetAdminById()
	{
		Admin admin =Admin.builder().aname("islam").aemail("islam@gmail.com").aphno("8235420562").
				userName("admin").password("admin123").role("admin").build();
		
		
		Optional<Admin> opAdmin=Optional.of(admin);
		Mockito.when(adminRepository.findById(admin.getId())).thenReturn(opAdmin);
		
		AdminDTO adto=adminConverter.convertToAdminDTO(admin);
		L.info("Getting  Admin by "+admin.getId() +" at "+ new java.util.Date());
		assertThat(adminService.getAdminById(admin.getId())).isNotEqualTo(adto);
		
	}
	
	
	
	
	
	
	
	
	
}
