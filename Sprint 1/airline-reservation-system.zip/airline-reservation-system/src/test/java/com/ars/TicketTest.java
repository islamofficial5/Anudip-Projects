package com.ars;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import com.ars.config.HibernateUtil;
import com.ars.entity.Airline;
import com.ars.model.TicketBookingDTO;
import com.ars.service.AdminService;
import com.ars.service.AirlineService;
import com.ars.service.FlightService;
import com.ars.service.TicketService;
import com.ars.serviceimpl.AdminServiceImpl;
import com.ars.serviceimpl.AirlineServiceImpl;
import com.ars.serviceimpl.FlightServiceImpl;
import com.ars.serviceimpl.TicketServiceImpl;

import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;

public class TicketTest
{
	private static Validator validator;
	FlightService flightService=new FlightServiceImpl();
	AirlineService airlineService=new AirlineServiceImpl();
	TicketService ticketService=new TicketServiceImpl();
	Airline airline=new Airline();
	
	
	private static SessionFactory sessionFactory;
	private Session session;
	
	@BeforeAll
	public static void setUp()
	{
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		validator = factory.getValidator();
		sessionFactory=HibernateUtil.getSessionFactory();
	}

	@BeforeEach
	public void OpenSession()
	{
		session=sessionFactory.openSession();
	}
	
	@AfterEach
	public void closeSession()
	{
		if(session!= null)
			session.close();
		System.out.println("Session closed");
	}
	
	@AfterAll
	public static void tearDown()
	{
		if(sessionFactory!=null)
			sessionFactory.close();
		System.out.println("Session factory closed");
	}
	
	@Test
	@DisplayName("testing booking flight ticket")
 	@Order(1)
	void testTicketBooking()
	{
			
		TicketBookingDTO td	=ticketService.bookFlight(2, 5, LocalDate.parse("2022-11-25"), "shawin@gmail.com", "Air India");
		
		assertNotNull(td);
	}
	@Test
	@DisplayName("testing AssignAirlineToFlight ")
 	@Order(3)
	void testAssignAirlineToFlight()
	{
		airlineService.assignAirlineToFlight(2,2);
		assertThat(flightService.getFlight(2).getAirline().getAirlineName()).isEqualTo("Air Asia");
	}
	
	@Test
	@DisplayName("negative test case ")
 	@Order(4)
	void testAssignAirlineToFlights()
	{
		airlineService.assignAirlineToFlight(2,2);
		assertThat(flightService.getFlight(2).getAirline().getAirlineName()).isEqualTo("Air India");
	}
}
