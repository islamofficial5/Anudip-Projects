package com.ars;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.LocalDate;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import com.ars.config.HibernateUtil;
import com.ars.entity.Flight;
import com.ars.exception.GlobalException;
import com.ars.model.FlightDTO;
import com.ars.model.PassengerDTO;
import com.ars.service.FlightService;
import com.ars.service.PassengerService;
import com.ars.serviceimpl.FlightServiceImpl;
import com.ars.serviceimpl.PassengerServiceImpl;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;

public class FlightTest
{
	private static Validator validator;
	FlightService flightService = new FlightServiceImpl();
	
	private static SessionFactory sessionFactory;
	private Session session;
	
	@BeforeAll
	public static void setUp()
	{
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		validator = factory.getValidator();
		sessionFactory=HibernateUtil.getSessionFactory();
	}

	@BeforeEach
	public void OpenSession()
	{
		session=sessionFactory.openSession();
	}
	
	@AfterEach
	public void closeSession()
	{
		if(session!= null)
			session.close();
		System.out.println("Session closed");
	}
	
	@AfterAll
	public static void tearDown()
	{
		if(sessionFactory!=null)
			sessionFactory.close();
		System.out.println("Session factory closed");
	}
	
	@Test
	@DisplayName("positive Test Case")
	@Order(1)
	 void testFlightNotNull()
	{
		
		FlightDTO flightdto=new FlightDTO(20, 200, "Economy", "10:10", LocalDate.parse("2022-11-02"), "delhi", "mumbai");
		
		Set<ConstraintViolation<FlightDTO>> constraintViolations =
			      validator.validate(flightdto);
		 //assertEquals( 1, constraintViolations.size() );
		//assertEquals("FlightClass should be more than 2 characters", constraintViolations.iterator().next().getMessage());
		assertThat(flightdto.getAvailableSeats()).isEqualTo(20);
		}
	
	
	
	
	@Test
	@DisplayName("negative Test Case")
	@Order(2)
	 void testFlightDateNot()
	{
		
		
		FlightDTO flightdto=new FlightDTO(100, 200, "economy", "10:10", null, "mumbai", "delhi");
		
		Set<ConstraintViolation<FlightDTO>> constraintViolations =
			      validator.validate( flightdto );
		 //assertEquals( 1, constraintViolations.size() );
		assertEquals("Flight Seats Can Not Be Null", constraintViolations.iterator().next().getMessage());
	}
	
	
	@Test
	@DisplayName("tetsing Add Flight ")
	@Order(3)
	 void testAddFlight()
	{
	
		LocalDate custdate1	= LocalDate.of(2022,11,12);
		
		
		System.out.println("..........Running TestAddFlight.............");
		Transaction tx=session.beginTransaction();
		Flight flight=Flight.builder().availableSeats(100).totalSeats(200).travellerClass("economy").
				time("10:15").date(custdate1). source("mumbai").destination("kolkata").build();
		
					
		Integer i=(Integer) session.save(flight);
		tx.commit();
	//	check flight is greater than 0
		assertThat(i>0).isTrue();
		
	}
	
	
	@Test
	@DisplayName("testing Update Flight ")
	@Order(4)
	public void testUpdateFlight()
	{
		System.out.println("..........Running TestUpdateFlight.............");
		Transaction tx=session.beginTransaction();
		
		Flight flight=Flight.builder().availableSeats(100).totalSeats(200).travellerClass("economy").
				time("10:15").date(LocalDate.parse("2022-11-12")). source("mumbai").destination("kolkata").build();
	
		session.save(flight);
		flight.setDestination("delhi");
		
		assertThat(flight.getDestination()).isEqualTo("delhi");
	}
	
	@Test
	@DisplayName("testing UpdateFlight using Service ")
	@Order(5)
	public void testUpdateFlightUsingService()
	{
		System.out.println("..........Running TestUpdateFlight.............");
		Transaction tx=session.beginTransaction();
		
		Flight flight =new Flight();
	
		flight.setAvailableSeats(100);
		flight.setTotalSeats(250);
		flight.setTravellerClass("economy");
		flight.setTime("10:40 PM");
		LocalDate custdate1	= LocalDate.of(2022,12,11);
		flight.setDate(custdate1);		
		flight.setSource("dubai");
		flight.setDestination("londan");
		
		FlightDTO fdto=flightService.updateFlight(18, flight);

		assertThat(fdto.getTotalSeats()).isEqualTo(250);
	}
	
	
	
	@Test
	@DisplayName("testing getFlight ")
	@Order(6)
	public void testgetFlight() {
		
		FlightDTO fdto=flightService.getFlight(2);
		assertThat(fdto.getDestination()).isEqualTo("Hyderabad");
	}
	
	

	@Test
	@DisplayName("testing delete airline")
	@Order(7)
	 void testDeleteFlight() {
		
		flightService.deleteFlight(22);
		
		assertThrows(GlobalException.class, () -> flightService.getFlight(4));		
	}
}
