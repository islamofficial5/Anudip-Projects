package com.ars;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import com.ars.config.HibernateUtil;
import com.ars.entity.Airline;
import com.ars.entity.Flight;
import com.ars.model.AirlineDTO;
import com.ars.service.AirlineService;
import com.ars.service.FlightService;
import com.ars.service.PassengerService;
import com.ars.serviceimpl.AirlineServiceImpl;
import com.ars.serviceimpl.FlightServiceImpl;
import com.ars.serviceimpl.PassengerServiceImpl;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;

public class AirlineTest
{
	private static Validator validator;
	FlightService flightService = new FlightServiceImpl();
	AirlineService airlineService = new AirlineServiceImpl();
	
	private static SessionFactory sessionFactory;
	private Session session;
	
	@BeforeAll
	public static void setUp()
	{
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		validator = factory.getValidator();
		sessionFactory=HibernateUtil.getSessionFactory();
	}

	@BeforeEach
	public void OpenSession()
	{
		session=sessionFactory.openSession();
	}
	
	@AfterEach
	public void closeSession()
	{
		if(session!= null)
			session.close();
		System.out.println("Session closed");
	}
	
	@AfterAll
	public static void tearDown()
	{
		if(sessionFactory!=null)
			sessionFactory.close();
		System.out.println("Session factory closed");
	}
	
	@Test
	@DisplayName("Positive Test Case")
	@Order(1)
	 void testAirlineNotNull()
	{
		
		AirlineDTO airlineDTO=new AirlineDTO("Air India", 5400);
		
		Set<ConstraintViolation<AirlineDTO>> constraintViolations = validator.validate(airlineDTO);
		 //assertEquals( 1, constraintViolations.size() );
		assertThat(airlineDTO.getAirlineName()).isEqualTo("Air India");
	}
	
	@Test
	@DisplayName("Negative Test Case")
	@Order(2)
	 void testAirlineName()
	{
		AirlineDTO airlineDTO=new AirlineDTO(null, 500);
		
		Set<ConstraintViolation<AirlineDTO>> constraintViolations =
			      validator.validate( airlineDTO );
		
		assertEquals("AdminName should be more than 2 characters", constraintViolations.iterator().next().getMessage());
	}
	
	@Test
	@DisplayName("tetsing Add Airline ")
	@Order(3)
	 void testAddFlight()
	{
	System.out.println("..........Running TestAddFlight.............");
		
		Transaction tx=session.beginTransaction();
		
		Airline airline=Airline.builder().airlineName("Emirates").fare(6500).build();
		
		
					
		Integer i=(Integer) session.save(airline);
		tx.commit();
	//	check flight is greater than 0
		assertThat(i>0).isTrue();	
	}
	
	@Test
	@DisplayName("testing Update Airline ")
	@Order(4)
	public void testUpdateAirline()
	{
		System.out.println("..........Running TestUpdateAdmin.............");
		Transaction tx=session.beginTransaction();
		Airline airline=Airline.builder().airlineName("Indigo").fare(4500).build();
				
		
		session.save(airline);
		airline.setAirlineName("Air India");
		
		assertThat(airline.getAirlineName()).isEqualTo("Air India");
	}
	
	
	

	@Test
	@DisplayName("testing UpdateAirline using Service ")
	@Order(5)
	public void testUpdateAirlineUsingService()
	{
		System.out.println("..........Running TestUpdateAirlineUsingService.............");
		Transaction tx=session.beginTransaction();
		
		Flight flight =new Flight();
		Airline airline=new Airline();
		
		airline.setAirlineName("Vistara");
		airline.setFare(5000.55f);
	
		AirlineDTO adto=airlineService.updateAirline(6, airline);

		assertThat(adto.getFare()).isEqualTo(5000.55f);
	}

	@Test
	@DisplayName("testing getAirlineById ")
	@Order(6)
	void testGetAirlineNameById()
	{
		AirlineDTO adto = airlineService.getAirlineById(1);
		assertThat(adto.getAirlineName()).isEqualTo("Air India");
		
	}
	
		@Test
		@DisplayName("testing delete airline")
		@Order(7)
	void testDeleteAirline()
	{
		airlineService.deleteAirline(12);
		assertThrows(Exception.class, ()-> airlineService.getAirlineById(12) );
	}
	
	
	
	@Test
	@DisplayName("testing OneToManyRelationshiop")
	@Order(8)
	void OneToManyRelationshipTest()
	{
		Airline airline=Airline.builder().airlineName("Air india").fare(5000).build();
		
		Flight flight1=Flight.builder().airline(airline).availableSeats(10).date(LocalDate.of(2022, 10, 20)).
				destination("mumbai").source("kolkata").time("05:10").build();

		Flight flight2=Flight.builder().airline(airline).availableSeats(10).date(LocalDate.of(2022, 10, 20)).
				destination("delhi").source("kolkata").time("06:10").build();
		
		List<Flight> flights=new ArrayList<>();
		flights.add(flight1);
		flights.add(flight2);
		
		airline.setFlights(flights);
		
		flightService.saveFlight(flight1);
		flightService.saveFlight(flight2);
		
		assertThat(flight1.getAirline()).isEqualTo(airline);
		assertThat(flight2.getAirline()).isEqualTo(airline);
		
		assertThat(airline.getFlights().get(0).getFlight_id()).isEqualTo(flight1.getFlight_id());
		assertThat(airline.getFlights().get(1).getFlight_id()).isEqualTo(flight2.getFlight_id());
	}
}
