package com.ars;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.ars.config.HibernateUtil;
import com.ars.entity.Admin;
import com.ars.exception.GlobalException;
import com.ars.model.AdminDTO;
import com.ars.model.PassengerDTO;
import com.ars.service.AdminService;
import com.ars.service.PassengerService;
import com.ars.serviceimpl.AdminServiceImpl;
import com.ars.serviceimpl.PassengerServiceImpl;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;

public class AdminTest
{
	private static Validator validator;
	AdminService adminService = new AdminServiceImpl();
	
	private static SessionFactory sessionFactory;
	private Session session;
	
	@BeforeAll
	public static void setUp()
	{
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		validator = factory.getValidator();
		sessionFactory=HibernateUtil.getSessionFactory();
	}

	@BeforeEach
	public void OpenSession()
	{
		session=sessionFactory.openSession();
	}
	
	@AfterEach
	public void closeSession()
	{
		if(session!= null)
			session.close();
		System.out.println("Session closed");
	}
	
	@AfterAll
	public static void tearDown()
	{
		if(sessionFactory!=null)
			sessionFactory.close();
		System.out.println("Session factory closed");
	}
	
	@Test
	@DisplayName("Positive Test Case")
	public void AdminNotNull()
	{
		AdminDTO adminDTO = new AdminDTO("s", "sohail@gmail.com");
		Set<ConstraintViolation<AdminDTO>> constraintViolations = validator.validate(adminDTO);
		//assertEquals(1, constraintViolations.size());
		assertEquals("AdminName should be more than 2 characters", constraintViolations.iterator().next().getMessage());
	}
	
	@Test
	@DisplayName("Negative Test Case")
	public void AdminEmailTest()
	{
		AdminDTO adminDTO=new AdminDTO("p",  null);
		Set<ConstraintViolation<AdminDTO>> constraintViolations = validator.validate( adminDTO);
		assertEquals("AdminEmail Can Not Be Blank", constraintViolations.iterator().next().getMessage());
	}
	
	@Test
	public void testSaveAdmin()
	{
		System.out.println("..........Running TestSaveAdmin.............");
		Transaction tx=session.beginTransaction();
		Admin ad = Admin.builder().aName("asif").email("asif@gmail.com").UserName("Asif").password("asif123").role("admin").build();
		Integer i=(Integer) session.save(ad);
		tx.commit();
		assertThat(i>0).isTrue();
		
	}
	
	@Test
	public void testUpdateAdmin()
	{
		System.out.println("..........Running TestUpdateAdmin.............");
		Transaction tx=session.beginTransaction();
		Admin ad = Admin.builder().aName("shawin").email("shawin@gmail.com").build();
		session.save(ad);
		ad.setAName("shawin");
		assertThat(ad.getAName()).isEqualTo("shawin");
	}
	
	@Test
	public void testUpdateAdminUsingService()
	{
		System.out.println("..........Running TestUpdateAdmin.............");
		Transaction tx=session.beginTransaction();
		Admin a = new Admin();
		a.setAName("suraj");
		a.setEmail("surajk@gmail.com");
		a.setUserName("suraj");
		a.setPassword("suraj123");
		a.setRole("user");
		AdminDTO adto = adminService.updateAdmin(6, a);
		
		
		assertThat(adto.getAName()).isEqualTo("suraj");
	}
	
	
		
		@Test
		public void testReadAdmin() 
		{
			AdminDTO adto = adminService.getAdminById(5);
			assertThat(adto.getAName()).isEqualTo("sohail");
		}
		
		@Test
		 void testDeleteAdmin()
		{
			adminService.deleteAdmin(7);
			
			assertThrows(GlobalException.class, ()-> adminService.getAdminById(7));
		}
	
		
	}
	

