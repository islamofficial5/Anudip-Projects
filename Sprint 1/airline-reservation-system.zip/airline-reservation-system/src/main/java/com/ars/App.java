package com.ars;



import javax.swing.JOptionPane;

import com.ars.entity.Admin;
import com.ars.entity.Passenger;
import com.ars.service.AdminService;
import com.ars.service.PassengerService;
import com.ars.serviceimpl.AdminServiceImpl;
import com.ars.serviceimpl.PassengerServiceImpl;

/**
 * Hello world!
 
 */
public class App 
{
	
    public static void main( String[] args )
    {
    	
      mainMenu();
    }
    
    public static void mainMenu()
    {
    	System.out.println("============================================================================");
    	System.out.println("Press A for Admin\nPress P for Passenger\nPress Q for exit");
        String choice=JOptionPane.showInputDialog("Enter choice","Type here");
        System.out.println("============================================================================");
       
         switch(choice)
         {
         	case "A": mainAdmin();
         	break;
         
         	case "P": mainUser();
         	break;
         
         	case "Q": System.exit(0);
         }	
    }
    
    public static void mainAdmin()
    {
    	AdminService aService=new AdminServiceImpl();
    	
    	 String choice;
    	   while(true)
    	   {
    	    	System.out.println("Press R for Registration\n"+ "Press L for Login\n"+ "Press Q for exit");
    	        choice=JOptionPane.showInputDialog("Enter choice","Type here");
    	      
    	        switch(choice)
    	        {
    	        	case "R":
    	       
    		        Admin admin=new Admin();
    		        admin.setAName("Sunny");
    		        admin.setEmail("sunny@gmail.com");
    		        admin.setUserName("root");
    		        admin.setPassword("root123");
    		        admin.setRole("admin");
    		        
    		        aService.registerAdmin(admin);
    		       
    		        System.out.println("Admin Registration has done successfully");
    		        break;
    		        
    	        	case "L":
    	        	boolean status=aService.loginAdmin(JOptionPane.showInputDialog("Enter UserName","Type here"),
    	        			JOptionPane.showInputDialog("Enter password","Type here"));
    	        	if(status==true)
    	        	{
    	        		System.out.println("Admin Login Succesfull");
    	        		CrudOperation.AdminOpeartion();
    	        	}	
    	        	else
    	        		System.out.println("Invalid Credentials!!");
    	        		System.exit(0);
    	        		break;
    	        	
    	        		case "Q":
    	        			mainMenu();
    	        	}
    	      }
    }
    
    public static void mainUser()
    {
    	PassengerService pservice=new PassengerServiceImpl();
        String choice;
       
        	System.out.println("Press R for Registration\n"+ "Press L for Login\n"+ "Press Q for exit");
            choice=JOptionPane.showInputDialog("Enter choice","Type here");
            switch(choice)
            {
            	case "R":
            	Passenger passenger1=new Passenger();
    	        passenger1.setName("Suraj Kumar");
    	        passenger1.setEmail("suraj@gmail.com");
    	        passenger1.setPhno("9572645390");
    	        passenger1.setUserName("suraj");
    	        passenger1.setPassword("suraj123");
    	        passenger1.setRole("user");
    	        
    	        //for save passenger,invoking savePassenger() method from service class
    	        pservice.savePassenger(passenger1);
    	        
    	        System.out.println("passenger Registration has done successfully");
    	        break;
    	        
            	case "L":
            	boolean status=pservice.login(JOptionPane.showInputDialog("Enter UserName","Type here"),
            			JOptionPane.showInputDialog("Enter password","Type here"));
            	if(status==true)
            	{
            		System.out.println("login succesfull");
            		CrudOperation.passengerOpearation();
            	}
            	else
            		System.out.println("Invalid Credentials!!");
            		System.exit(0);
            		break;
            	
            	case "Q":
            	System.exit(0);
            }
        }
}
