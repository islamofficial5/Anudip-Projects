package com.ars.daoimpl;

import javax.swing.JOptionPane;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ars.config.HibernateUtil;
import com.ars.dao.AdminDAO;
import com.ars.entity.Admin;
import com.ars.entity.Passenger;

public class AdminDAOImpl implements AdminDAO
{
	private static final Logger Logger=LoggerFactory.getLogger(AdminDAOImpl.class);

	@Override
	public void registerAdmin(Admin admin) 
	{
		Session session=HibernateUtil.getSession();
		session.beginTransaction();
		session.save(admin);
		session.getTransaction().commit();
		Logger.info("new admin has been added"+admin.toString()+" and creation date is: "+ new java.util.Date()+"and creation time is "+new java.util.Timer());
		
		session.close();
	}

	@Override
	public boolean loginAdmin(String userName, String password) 
	{
		Session session=HibernateUtil.getSession();
		Admin admin=(Admin)session.get(Admin.class,Integer.parseInt(JOptionPane.showInputDialog("enter Id:","Type here")));
		
		if(admin.getUserName().equals(userName) && admin.getPassword().equals(password))	
		{
			Logger.info(admin.toString()+" login successfully at:"+ new java.util.Date());
			return true;
		}
		else
		{
			return false;
		}
		
	}

	@Override
	public Admin updateAdmin(int id, Admin admin) 
	{
		try(Session session=HibernateUtil.getSession())
		{	
			Admin ad=(Admin)session.load(Admin.class, id);
			
			//update existing details with new one
			ad.setAName(admin.getAName());
			ad.setEmail(admin.getEmail());
			ad.setRole(admin.getRole());
			ad.setUserName(admin.getUserName());
			ad.setPassword(admin.getPassword());
			
				
			session.beginTransaction();
			session.saveOrUpdate(ad);
			session.getTransaction().commit();
			Logger.info(ad.toString()+" update successfully at:"+ new java.util.Date());

			return ad;// return passenger entity
			
		}
		catch (HibernateException e) 
		{
			System.out.println("hibernate exception is: "+ e);
		}
					
		catch (Exception e) 
		{
			System.out.println("exception is: "+ e);
		}
		return null;
	}

	@Override
	public Admin getAdmin(int id) 
	{
		try(Session session=HibernateUtil.getSession())
		{
			Admin ad=(Admin)session.get(Admin.class, id);
			Logger.info(ad.toString()+" Passenger details fetch successfully at:"+ new java.util.Date());

			return ad;	
		}
			
		catch (HibernateException e) 
		{
			System.out.println("hibernate exception is: "+ e);
		}
			
		catch (Exception e) 
		{
			System.out.println("exception is: "+ e);
		}
		return null;
	}

	@Override
	public void deleteAdmin(int id) 
	{
		try(Session session=HibernateUtil.getSession())
		{	
			Admin ad=session.load(Admin.class, id);
			
			session.beginTransaction();
			int input=JOptionPane.showConfirmDialog(null, "do you want to delete?","select what you want to delete or not?",JOptionPane.YES_NO_OPTION);
				
			if(input==0)
			{
				session.delete(ad);
				JOptionPane.showMessageDialog(null, "Object is deleted!!!!");
			}
			else
				JOptionPane.showMessageDialog(null, "User wants to retain it!!!");
				Logger.info(ad.toString()+" Passenger deleted successfully at:"+ new java.util.Date());

				session.getTransaction().commit();
			
			}
			catch (HibernateException e)
			{
				System.out.println("hibernate exception is: "+ e);
			}
				
			catch (Exception e) 
			{
				System.out.println("exception is: "+ e);
			}
		
		}

}
