package com.ars.daoimpl;

import java.util.List;

import javax.persistence.PersistenceException;
import javax.swing.JOptionPane;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ars.config.HibernateUtil;
import com.ars.dao.FlightDAO;
import com.ars.entity.Admin;
import com.ars.entity.Flight;
import com.ars.entity.Passenger;

public class FlightDAOImpl implements FlightDAO
{
	private static final Logger Logger=LoggerFactory.getLogger(FlightDAOImpl.class);

	@Override
	public void saveFlight(Flight flight) 
	{
		try(Session session=HibernateUtil.getSession())
		{
			//adding new flight details
			session.beginTransaction();
			session.save(flight);
			
			//java object saved to database
			session.getTransaction().commit();
			
			Logger.info("new passenger has been added"+flight.toString()
			+" and creation date is: "+ new java.util.Date()+"and creation time is "+new java.util.Timer());
			
			
			//clear the session
			session.clear();
		}
		catch (HibernateException e)
		{
			System.out.println("hibernate exception is: "+ e);
		}
			
		catch (Exception e) 
		{
			System.out.println("exception is: "+ e);
		}	
		
	}

	@Override
	public Flight updateFlight(int id, Flight flight) 
	{
		try(Session session=HibernateUtil.getSession())
		{
		
			Flight fl=(Flight)session.load(Flight.class, id);
			
			//update existing details with new one
			fl.setAvailableSeats(flight.getAvailableSeats());
			fl.setTotalSeats(flight.getTotalSeats());
			fl.setTravellerClass(flight.getTravellerClass());
			fl.setTime(flight.getTime());
			fl.setDate(flight.getDate());
			fl.setSource(flight.getSource());
			fl.setDestination(flight.getDestination());
			
			
			session.beginTransaction();
			session.saveOrUpdate(fl);
			session.getTransaction().commit();
			Logger.info(fl.toString()+" update successfully at:"+ new java.util.Date());

			return fl;// return passenger entity
			
		}
		catch (HibernateException e) 
		{
			System.out.println("hibernate exception is: "+ e);
		}
					
		catch (Exception e) 
		{
			System.out.println("exception is: "+ e);
		}
		return null;
	}

	@Override
	public Flight getFlight(int id) 
	{
		try(Session session=HibernateUtil.getSession())
		{
			Flight flight =(Flight)session.get(Flight.class, id);
			Logger.info(flight.toString()+" Flight details fetch successfully at:"+ new java.util.Date());

			return flight;
		}
		catch (HibernateException e)
		{
			System.out.println("hibernate exception is: "+ e);
		}
					
		catch (Exception e)
		{
			System.out.println("exception is: "+ e);
		}	
        
		return null;
	}

	@Override
	public void deleteFlight(int id) 
	{
		try(Session session=HibernateUtil.getSession())
		{
			Flight fl = session.load(Flight.class, id);
			
			
			session.beginTransaction();
			int input=JOptionPane.showConfirmDialog(null, "do you want to delete?",
					"select what you want to delete or not?",JOptionPane.YES_NO_OPTION);
				
			if(input==0)
			{
				session.delete(fl);				
			}
			else
				Logger.info(fl.toString()+" Flight deleted successfully at:"+ new java.util.Date());

				JOptionPane.showMessageDialog(null, "User wants to retain it!!!");
			
				session.getTransaction().commit();
			
			}
			catch (HibernateException e) 
			{
				System.out.println("hibernate exception is: "+ e);
			}
				
			catch (PersistenceException e) 
			{
				throw new PersistenceException("You can not delete your account as you have booking with us");
			}
	}

	@Override
	public List<Flight> checkFlight(String from, String to) 
	{
	        try(Session session=HibernateUtil.getSession())
	        {
	        	String q="from Flight as f where f.source=:s and f.destination=:d";
	        	Query query=session.createQuery(q);
	        	query.setParameter("s", from);
	        	query.setParameter("d", to);
	        	List<Flight> flights=query.list();
	    		Logger.info(flights.toString()+" Flight checked successfully at:"+ new java.util.Date());

	        	return flights;
	        }
	        catch (HibernateException e) 
	        {
				System.out.println("hibernate exception is: "+ e);
			}
				
			catch (Exception e) 
	        {
				System.out.println("exception is: "+ e);
			}	
	        return null;
	}

}
