package com.ars.model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;


import com.ars.entity.Airline;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@NoArgsConstructor
public class FlightDTO 
{
	private int flight_id;

	@NotNull(message = "{f.Seat.check}")
	private int availableSeats;

	@NotNull(message = "{f.Seat.check}")
	private int totalSeats;
	
	@NotNull(message = "{f.class.check}")
	private String travellerClass;

	@NotNull(message = "{f.time.check}")
	private String time;

	@NotNull(message = "{f.date.check}")
	private LocalDate date;

	@NotNull(message = "{f.source.check}")
	private String source;
	
	@Size(min = 2,message = "{f.sourceSize.check}")
	@NotNull(message = "{f.destination.check}")
	@Size(min = 2,message = "{f.destinationsize.check}")
	private String destination;

	private Airline airline;

	public FlightDTO(@NotNull(message = "{f.Seat.check}") int availableSeats,
			@NotNull(message = "{f.Seat.check}") int totalSeats,
			@NotNull(message = "{f.class.check}") String travellerClass,
			@NotNull(message = "{f.time.check}") String time, @NotNull(message = "{f.date.check}") LocalDate date,
			@NotNull(message = "{f.source.check}") String source,
			@Size(min = 2, message = "{f.sourceSize.check}") @NotNull(message = "{f.destination.check}") @Size(min = 2, message = "{f.destinationsize.check}") String destination) {
		super();
		this.availableSeats = availableSeats;
		this.totalSeats = totalSeats;
		this.travellerClass = travellerClass;
		this.time = time;
		this.date = date;
		this.source = source;
		this.destination = destination;
	}
	
	
}
