package com.ars;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.swing.JOptionPane;

import com.ars.dao.AdminDAO;
import com.ars.entity.Admin;
import com.ars.entity.Airline;
import com.ars.entity.Flight;
import com.ars.entity.Passenger;
import com.ars.entity.TicketGenerationPdf;
import com.ars.model.AdminDTO;
import com.ars.model.AirlineDTO;
import com.ars.model.FlightDTO;
import com.ars.model.PassengerDTO;
import com.ars.model.TicketBookingDTO;
import com.ars.service.AdminService;
import com.ars.service.AirlineService;
import com.ars.service.FlightService;
import com.ars.service.PassengerService;
import com.ars.service.TicketService;
import com.ars.serviceimpl.AdminServiceImpl;
import com.ars.serviceimpl.AirlineServiceImpl;
import com.ars.serviceimpl.FlightServiceImpl;
import com.ars.serviceimpl.PassengerServiceImpl;
import com.ars.serviceimpl.TicketServiceImpl;

public class CrudOperation {

	static PassengerService pservice=new PassengerServiceImpl();
	static AdminService aservise=new AdminServiceImpl();
	static FlightService fService=new FlightServiceImpl();
	static AirlineService aService=new AirlineServiceImpl();
	static TicketService tService=new TicketServiceImpl();
	
	//this method is responsible to perform crud  operation of instructor
		public static void crudPassenger()
		{
			String pchoice;
			while(true) {
			System.out.println("============================================================================");
			System.out.println( "Press r. for read Passenger details\n Press u.for update Passenger details\n Press d.for delete Passenger details\n"+ " Press q for quit");
			System.out.println("============================================================================");
			pchoice=JOptionPane.showInputDialog("Enter choice","Type here");

			switch(pchoice)
			{
			case "r":
				try
				{
					PassengerDTO pDto=pservice.getPassengerById(Integer.parseInt(JOptionPane.showInputDialog("Enter id", "type here")));
					System.out.println("Passenger details: ");
					System.out.println("Id: "+pDto.getId());
					System.out.println("Name: "+pDto.getName());
					System.out.println("Ph. No: "+pDto.getPhno());
					System.out.println("Email: "+pDto.getEmail());
				}
				catch (Exception e) 
				{
					System.out.println(e);
				}
				break;
		
			case "u":

				Passenger passenger=new Passenger();
				passenger.setName("Suraj Kumar");
				passenger.setEmail("suraj@gamil.com");
				passenger.setPhno("9572645390");
				passenger.setUserName("suraj");
				passenger.setPassword("suraj123");
				passenger.setRole("user");
		
				PassengerDTO upPass=pservice.updatePassenger(Integer.parseInt(JOptionPane.showInputDialog("enter id to update", "type here")),passenger);
				System.out.println("Passenger updated successfully");
				break;	

			case "d":
				pservice.deletePassenger(Integer.parseInt(JOptionPane.showInputDialog("enter id to delete", "type here")));
				JOptionPane.showMessageDialog(null, "Object is deleted!!!!");
				break;

			case "q":
				passengerOpearation();
				break;

			}//end of switch
		}
	} //crud passenger
		
		
		
		
			
		public static void crudAdmin()
		{
			String xx;
			while(true) {
			System.out.println("============================================================================");
			System.out.println( "Press r. for Read Admin details\n "+ "Press u.for Update Admin details\n " + "Press d.for Delete Admin details\n"+ "Press q for Quit");
			System.out.println("============================================================================");
			xx=JOptionPane.showInputDialog("Enter choice","Type here");

			switch(xx)
			{
			case "r":
				try
				{
					AdminDTO adto=aservise.getAdminById(Integer.parseInt(JOptionPane.showInputDialog("Enter id", "type here")));
					System.out.println("Admin details: ");
					System.out.println("Admin Id: "+adto.getId());
					System.out.println("Admin Name: "+adto.getAName());
					System.out.println("Admin Email: "+adto.getEmail());	
				}
				catch (Exception e) 
				{
					System.out.println(e);
				}
				break;
		
				
			case "u":
				Admin admin=new Admin();
		 
				admin.setAName("Suraj Kumar");
				admin.setEmail("surajk@gmail.com");
				admin.setUserName("root");
				admin.setPassword("root123");
				admin.setRole("admin");

				AdminDTO upAdmi=aservise.updateAdmin(Integer.parseInt(JOptionPane.showInputDialog("enter id to update", "type here")),admin);
	
				System.out.println("Admin updated successfully");
				break;	

			case "d":
				aservise.deleteAdmin(Integer.parseInt(JOptionPane.showInputDialog("enter id to delete", "type here")));
				break;

			case "q":
				passengerOpearation();
				break;

			}//end of switch
		}
			} //crud admin
		
		
		
		
		
		//this method is responsible to  perform crud operation of flight
		public static void crudFlight()
		{
			String in;
			while(true) {
			System.out.println("============================================================================");
			System.out.println("Press c. for add Flight details\n"+ "Press r. for flight details\n Press u.for update flight details\n Press d.for delete flight details\n"
			+ " Press q for quit ");
			System.out.println("============================================================================");
			in=JOptionPane.showInputDialog("Enter choice","Type here");
		
			switch(in)
			{
				case "c":
					Flight flight3=new Flight();
					flight3.setAvailableSeats(100);
					flight3.setTotalSeats(200);
					flight3.setTravellerClass("business");
					flight3.setTime("11:10");
					LocalDate custDate1 = LocalDate.of(2022, 11, 25);
					flight3.setDate(custDate1);
					flight3.setSource("Kolkata");
					flight3.setDestination("Hyderabad");
					fService.saveFlight(flight3);
					System.out.println("Flight added successfully!!");
					break;
		
				case "r":
					try 
					{
						FlightDTO fdto = fService.getFlight(Integer.parseInt(JOptionPane.showInputDialog("Enter id", "type here")));
				
						System.out.println("Flight details: ");
						System.out.println("Flight Id: "+fdto.getFlight_id());
						System.out.println("Flight available seats: "+fdto.getAvailableSeats());
						System.out.println("Flight Total seats: "+fdto.getTotalSeats());
						System.out.println("Flight class:"+fdto.getTravellerClass());
						System.out.println("Flight time:"+fdto.getTime());
						System.out.println("Flight date:"+fdto.getDate());
						System.out.println("Flight source:"+fdto.getSource());
						System.out.println("Flight destination:"+fdto.getDestination());
				}
				catch (Exception e) 
				{
					System.out.println(e);
				}
				break;
				
				case "u":
					Flight flight = new Flight();
			 
					flight.setAvailableSeats(150);
					flight.setTotalSeats(200);
					flight.setTravellerClass("Economy");
					flight.setTime("10:15");
					LocalDate custDate2 = LocalDate.of(2022, 11, 30);
					flight.setDate(custDate2);
					flight.setSource("Kolkata");
					flight.setDestination("Delhi");
			 
					FlightDTO upFlight = fService.updateFlight(Integer.parseInt(JOptionPane.showInputDialog("enter id to update", "type here")),flight);
		
					System.out.println("Flight updated successfully");
					break;	

				case "d":
					fService.deleteFlight(Integer.parseInt(JOptionPane.showInputDialog("enter id to delete", "type here")));
					break;

				case "q":
					AdminOpeartion();
					break;
				default:
					System.out.println("wrong input");
		
			}//switch 
		}
	} //crud flight
	
		
		//this method is responsible to assign flights to airline		
		public static void assignAirlineToFlight()
		{
			aService.assignAirlineToFlight(2, 2);  //(flightId, airlineId)
			System.out.println("flight assign to airline successfully");
		}	
		public static void crudAirline()
		{
			String in;
			while(true) 
			{
				System.out.println("============================================================================");
				System.out.println("Press c. for add Airline details\n"+ "Press r. for get AIrline details\n "+ "Press u.for update Airline details\n"+ "Press d.for delete Airline details\n"+ "Press q for quit ");
				System.out.println("============================================================================");
				in=JOptionPane.showInputDialog("Enter choice","Type here");
				switch(in)
				{
				case "c":
					Airline airline2=new Airline();
					airline2.setAirlineName("Spicejet");
					airline2.setFare(6800.55f);
					aService.saveAirline(airline2);
					System.out.println("Airline saved succeessfully");
					break;
				case "r":
					try 
					{
						AirlineDTO airlinedto=aService.getAirlineById(Integer.parseInt(JOptionPane.showInputDialog("Enter id", "type here")));
						System.out.println("Passenger details: ");
						System.out.println("Airline Id: "+airlinedto.getId());
						System.out.println("Airline Name: "+airlinedto.getAirlineName());
						System.out.println("Airline Fare: "+airlinedto.getFare());	
					}
					catch (Exception e)
					{
						System.out.println(e);
					}
					break;
	    
	   
				case "u":
					Airline airline=new Airline();
		
					airline.setAirlineName("Air India");
					airline.setFare(5500.20f);
		 
					AirlineDTO upAirline=aService.updateAirline(Integer.parseInt(JOptionPane.showInputDialog("enter id to update", "type here")),airline);
	
					System.out.println("Airline updated successfully");
		
					break;
		
				case "d":
					aService.deleteAirline(Integer.parseInt(JOptionPane.showInputDialog("enter id to delete", "type here")));
					break;

				case "q":
					AdminOpeartion();
					break;
				}//end of switch
			}//end of while
	}//end of method
		

		public static void 	bookFlight()
		{
			List<Flight> flights=fService.checkFlight(JOptionPane.showInputDialog("Enter From","Type here"),
			JOptionPane.showInputDialog("Enter To","Type here"));
			System.out.println("Flight Id \t Airline Name \t From \t To \t Fare \t Class  \t Timing \tDate ");
			for(Flight flight: flights)
			{
				System.out.println(flight.getFlight_id() +"\t\t"+ flight.getAirline().getAirlineName()+"\t"+ 
			flight.getSource()+"\t"+ flight.getDestination()+"\t"+flight.getAirline().getFare()+"\t"+
			flight.getAirline().getClass()	+"\t"+flight.getTime()+"\t"+flight.getDate());
				
			}
			System.out.println("For booking press Yes");
			String choice=JOptionPane.showInputDialog("Tpye yes for book flights ","Type here");
			if(choice.equalsIgnoreCase("yes"))
			{
				int flight_id=Integer.parseInt(JOptionPane.showInputDialog("Enter Flight ID","Type here"));
				int no_of_passenger=Integer.parseInt(JOptionPane.showInputDialog("Enter total passenger","Type here"));
				LocalDate date=LocalDate.parse(JOptionPane.showInputDialog("Enter Date","YYYY-MM-DD"));
				String pEmail=JOptionPane.showInputDialog("Enter Passenger Email","Type here");
				String airName=JOptionPane.showInputDialog("Enter AirLine Name","Type here");
				TicketBookingDTO ticketDTO=tService.bookFlight(flight_id, no_of_passenger, date, pEmail, airName);
				System.out.println("your booking has done successfully");
				TicketGenerationPdf.TicketGeneration(ticketDTO);
			}
		}
	
	
	
		//sub menu to choose menu
		public static void passengerOpearation()
		{
	    	int input;
	    	while(true)
	    	{
	    		System.out.println("============================================================================");
	    		System.out.println("Press 1. for Passenger details\n Press 2. for check flights\n"+ "Press 3. for book flight\n Press 4. for quit");
	    		input=Integer.parseInt(JOptionPane.showInputDialog("Enter choice","Type here"));
	    		System.out.println("============================================================================");
	    	
	    		switch(input){
	    		
	    		case 1:
	    			crudPassenger();
	    			break;
	    	
	    		case 2:
	    			
	    			List<Flight> flights= fService.checkFlight(JOptionPane.showInputDialog("Enter From","Type here"),
	             			JOptionPane.showInputDialog("Enter To","Type here"));
	                 System.out.println("Flight Id \t Airline Name \t From \t To \t Fare \t Class  \t Timing \tDate ");
	             	for(Flight flight: flights)
	             	{
	             		System.out.println(flight.getFlight_id() +"\t\t"+ flight.getAirline().getAirlineName()+"\t"+ 
	             	flight.getSource()+"\t"+ flight.getDestination()+"\t"+flight.getAirline().getFare()+"\t"+
	             		flight.getAirline().getClass()	+"\t"+flight.getTime()+"\t"+flight.getDate());
	             	}
	    			break;
	    		
	    		case 3:
	    			bookFlight();
	    			break;
	    		case 4:
	    			App.mainMenu();
	    			break;
	    		}
	    	}
		}
		
		
	    	public static void AdminOpeartion()
			{
		    	int input;
		    	while(true) 
		    	{
		    		System.out.println("============================================================================");
		    		System.out.println("Press 1. for Admin details\n  Press 2. for Flight details\n Press 3. for airline details\n"
		    			+ "Press 4. for add flight to airlines\n Press 5. for quit");
		    		input=Integer.parseInt(JOptionPane.showInputDialog("Enter choice","Type here"));
		    		System.out.println("============================================================================");
		    	
		    		switch(input)
		    		{
		    			case 1:
		    				crudAdmin();
		    				break;
		    		
		    			case 2:
		    				crudFlight();
		    				break;
		    	
		    			case 3:
		    				crudAirline();
		    				break;
    		
		    			case 4:
		    				assignAirlineToFlight();
		    				break;
		    			case 5:
		    				App.mainMenu();
		    				break;
		    		}
		    	}	
		}
}
