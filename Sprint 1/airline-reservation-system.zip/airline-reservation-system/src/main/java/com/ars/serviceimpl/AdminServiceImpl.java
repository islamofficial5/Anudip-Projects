package com.ars.serviceimpl;

import org.modelmapper.ModelMapper;


import com.ars.dao.AdminDAO;
import com.ars.daoimpl.AdminDAOImpl;
import com.ars.entity.Admin;
import com.ars.entity.Passenger;
import com.ars.exception.GlobalException;
import com.ars.model.AdminDTO;
import com.ars.service.AdminService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AdminServiceImpl implements AdminService
{
	private static final Logger Logger=LoggerFactory.getLogger(AdminServiceImpl.class);
	AdminDAO aDao=new AdminDAOImpl();
	
	
	@Override
	public void registerAdmin(Admin admin) 
	{
		Logger.info("inside register admin method: ");

		aDao.registerAdmin(admin);
	}

	
	@Override
	public boolean loginAdmin(String userName, String password) 
	{
		Logger.info("inside login admin method: ");
		return aDao.loginAdmin(userName, password);
	}

	
	@Override
	public AdminDTO updateAdmin(int id, Admin admin) 
	{
		Admin a=aDao.updateAdmin(id, admin);
		Logger.info("inside update admin method: ");
		return new ModelMapper().map(a, AdminDTO.class); //converting entity to DTO	
	}

	
	@Override
	public AdminDTO getAdminById(int id) throws GlobalException 
	{
		Logger.info("inside getAdminById method: ");
		Admin admin	=aDao.getAdmin(id);
		if(admin!=null)
		{
			return new ModelMapper().map(admin, AdminDTO.class);
		}
			throw new GlobalException("Admin details not exist!!");
	}
	

	@Override
	public void deleteAdmin(int id) 
	{
		aDao.deleteAdmin(id);
		Logger.info("inside delete admin method: ");	
	}
}
