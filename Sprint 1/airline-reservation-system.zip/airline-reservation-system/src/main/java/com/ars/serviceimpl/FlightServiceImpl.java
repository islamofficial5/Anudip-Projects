package com.ars.serviceimpl;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ars.dao.FlightDAO;
import com.ars.daoimpl.FlightDAOImpl;
import com.ars.entity.Flight;
import com.ars.entity.Passenger;
import com.ars.exception.GlobalException;
import com.ars.model.FlightDTO;
import com.ars.model.PassengerDTO;
import com.ars.service.FlightService;


public class FlightServiceImpl implements FlightService
{
	private static final Logger Logger=LoggerFactory.getLogger(FlightServiceImpl.class);

	FlightDAO flightDAO=new FlightDAOImpl();
	
	
	@Override
	public void saveFlight(Flight flight) 
	{
		flightDAO.saveFlight(flight);
		Logger.info("inside save flight method: ");
	}

	
	@Override
	public FlightDTO updateFlight(int id, Flight flight)
	{
		Flight f = flightDAO.updateFlight(id, flight);
		Logger.info("inside update flight method: ");
		return new ModelMapper().map(f, FlightDTO.class); //converting entity to DTO	
	}

	
	@Override
	public FlightDTO getFlight(int id) throws GlobalException
	{
		Logger.info("inside getFlight method: ");
		Flight flight = flightDAO.getFlight(id);
		if(flight!=null)
		{
			return new ModelMapper().map(flight, FlightDTO.class);
		}
			throw new GlobalException("Passenger details not exist!!");
	}

	
	@Override
	public void deleteFlight(int id) 
	{
		flightDAO.deleteFlight(id);
		Logger.info("inside delete flight method: ");	
	}

	
	@Override
	public List<Flight> checkFlight(String from, String to) 
	{	
		Logger.info("inside check flight method: ");
		return flightDAO.checkFlight(from, to);
	}
}
