package com.ars.service;

import com.ars.entity.Airline;
import com.ars.exception.GlobalException;
import com.ars.model.AirlineDTO;


public interface AirlineService 
{
	void saveAirline(Airline airline);
	void assignAirlineToFlight(int flightId, int airId);
	AirlineDTO updateAirline(int id,Airline airline);
	AirlineDTO getAirlineById(int id) throws GlobalException;
	void deleteAirline(int id);
}
