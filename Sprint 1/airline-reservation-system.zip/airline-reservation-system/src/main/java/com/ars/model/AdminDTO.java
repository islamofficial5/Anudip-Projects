package com.ars.model;



import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class AdminDTO extends UserDTO
{
	@NotNull(message = "{a.name.check}")
	@Size(min = 2, message = "{a.size.check}")
	private String AName;
    
	@NotNull(message = "{a.email.check}")
	@Email
	private String email;

	public AdminDTO(@NotNull(message = "{a.name.check}") @Size(min = 2, message = "{a.size.check}") String aName,
				@NotNull(message = "{a.email.check}") @Email String email) 
	{
		super();
		this.AName = aName;
		this.email = email;
	}
	
	
}
